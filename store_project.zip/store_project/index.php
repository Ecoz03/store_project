<!DOCTYPE html>
<html>

<head>
    <title>Product Catalog</title>
</head>

<body>
    <h1>Product Catalog</h1>

    <?php
        //TO DO: Connect to database
        //TO DO: Display product list with quantity input and "Add to Cart" button
    ?>

    <a href = "cart.php">Go to Cart</a>

</body>

</html>