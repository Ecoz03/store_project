<?php
//TO DO: Connect to database
//TO DO: Clear chart contents

//Redirect back to catalog

header("Location: index.php")
exit();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
</head>
<body>
    <h1>Processing Checkout...</h1>
    <p>If you're seeing this, the redirect didn't work.</p>
    <a href = "index.php">Return to Catalog</a>
</body>
</html>