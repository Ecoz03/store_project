<!DOCTYPE html>
<html>

<head>
    <title>Shopping Cart</title>
</head>

<body>
    <h1>Your Cart</h1>

    <?php
        //TO DO: Connect to database
        //TO DO: Display cart items with quantity, cost, and total
        //TO DO: Calculate tax, shipping, and order total
    ?>

    <a href = "index.php">Continue Shopping</a><br>
    <a href = "checkout.php">Check Out</a>
</body>
</html>